#!/bin/bash 
#
####################################################################################
#     MergeBasin: 
#       + Create 2 .txt files from a 4 .txt files containing ordered
#       points forming the contour of the domain 
#        (2 files(each basins) for the front = BC 1;
#         2 files (each basins) for the side of the drainage basin = BC 2)
#
# INPUT : "XX_cote.txt" ,
#         "YY_cote.txt"
#         and 
#         "XX_terre.txt" ,
#         "YY_terre.txt"
#                    (contains x,y coordinate of the contour points)
#
# OUTPUT: "MergeCote.txt" and "MergeTerre.txt" 
#                   (ascii files)
#
#  Author : L. Tavard; LGGE, Grenoble
####################################################################################
echo "==============================================================="
echo "Enter file name of basins  with Space-separator like"
echo " COTE1.txt COTE2.txt TERRE1.txt TERRE2.txt"
echo "==============================================================="
echo ""
read files
echo ""
#----------------------------------------------------------------------------------#
# Pre-traitement
#----------------------------------------------------------------------------------#
# Creation d'un dossier ou on va merger toutes les données
mkdir ./MergeDirectory  
# Existence of files 
for Name in $files; do
    if (test ! -e ./$Name); then
	echo ""
	printf "File [%s] does not found \n" $Name
	echo "==============================================================="
	echo ""
	rm -r ./MergeDirectory
	exit
    else
	# Copie des fichiers cotes et terre renommes en fonction du nom des dossiers
	cp ${Name} ./MergeDirectory/${Name}
    fi
done
cd ./MergeDirectory

#Variables
#----------
#Transformation de la liste des dossiers en tableau - pour varier les indices-
declare -a ArrayDir=( ${files[@]} )

#Variable fichiers:
NameFileCote1=${ArrayDir[0]}
NameFileCote2=${ArrayDir[1]}
NameFileTerre1=${ArrayDir[2]}
NameFileTerre2=${ArrayDir[3]}

#Variables d en-tete et fin de fichiers Cote
HeadFileCote1=`head -1 $NameFileCote1`
EndFileCote1=`tail -1 $NameFileCote1`
HeadFileCote2=`head -1 $NameFileCote2`
EndFileCote2=`tail -1 $NameFileCote2`

#Variables d en-tete et fin de fichiers Terre
EndFileTerre1=`tail -1 $NameFileTerre1`
HeadFileTerre2=`head -1 $NameFileTerre2`
EndFileTerre2=`tail -1 $NameFileTerre2`
HeadFileTerre1=`head -1 $NameFileTerre1`

#Variables pour le nom des fichiers de sortie
echo "Enter output file name for coast, ex: MergeCote.txt"
read NewFileCote
echo ""

echo "Enter output file name for Terre, ex: MergeTerre.txt"
read NewFileTerre
echo ""

# Sens de 'merging' 
#------------------
  
if ( test "$HeadFileCote1" = "$EndFileCote2" ); then
  # Ex: Basin1 à gauche,  Basin2 à droite
  # On change l'ordre de lecture pour être dans le bon sens
    echo 'Ordre des bassins inchange'

elif ( test "$HeadFileCote2" = "$EndFileCote1" ); then
  # Ex: Basin1 à droite,  Basin2 à gauche
  # On change l'ordre de lecture pour être dans le bon sens
    echo 'Changement ordre des bassins'

  #Variable fichiers:
    NameFileCote1=${ArrayDir[1]}
    NameFileCote2=${ArrayDir[0]}
    NameFileTerre1=${ArrayDir[3]}
    NameFileTerre2=${ArrayDir[2]}

  #Variables d en-tete et fin de fichiers Cote
    HeadFileCote1=`head -1 $NameFileCote1`
    EndFileCote1=`tail -1 $NameFileCote1`
    HeadFileCote2=`head -1 $NameFileCote2`
    EndFileCote2=`tail -1 $NameFileCote2`
    
  #Variables d en-tete et fin de fichiers Terre
    EndFileTerre1=`tail -1 $NameFileTerre1`
    HeadFileTerre2=`head -1 $NameFileTerre2`
    EndFileTerre2=`tail -1 $NameFileTerre2`
    HeadFileTerre1=`head -1 $NameFileTerre1`

else
  # Problème
  #---------
    echo '***********************************************'
    echo 'ERROR: Pas de variable communue'
    echo 'On ne merge pas les bassins versants'
    echo '***********************************************'
    exit
fi

#----------------------------------------------------------------------------------#
# 'Résolution'
#----------------------------------------------------------------------------------#
# Merge Cote
#-----------
echo "***********************************************"
echo "Merge cote"
echo "***********************************************"
Delete1=`sed '1d' $NameFileCote1`
cat $NameFileCote2 $NameFileCote1 > $NewFileCote
echo "Creation du nouveau fichier pour la cote: DONE"

# Merge Terre
#------------
echo "************************************************"
echo "Merge terre"
echo "************************************************"
if ( test "$EndFileTerre1" = "$HeadFileTerre2" ); then
    tmpFile1="tmp$NameFileTerre1"
    tac $NameFileTerre1 > $tmpFile1
    #On regarde le nombre de doublons sur les fichiers et on les supprime tous excepté le premier
    NbLine1=`cat $NameFileTerre1 | wc -l`
    echo "Nombre de lignes du Terre1.txt" $NbLine1
    NbLine2=`cat $NameFileTerre2 | wc -l`
    echo "Nombre de lignes du Terre2.txt" $NbLine2

    SameCoordTerre=`cat $NameFileTerre1 $NameFileTerre2 | sort -f | uniq -d > tmpDoublons.txt`
    NbreDoublon=`cat tmpDoublons.txt | wc -l`
    #echo "Nombre de doublons" $NbreDoublon
   
    NbreDoublon=`expr $NbreDoublon - 1`
    echo "Nombre de doublons enlevés" $NbreDoublon
   
    tmp2File1="tmp2$NameFileTerre1"
    sed "1,${NbreDoublon}d" $tmpFile1 > $tmp2File1
    
    tac $tmp2File1 > $NewFileTerre
    
    tmpFile2="tmp$NameFileTerre2"
    NbreDoublon=`expr $NbreDoublon + 1`
    tester=`sed "1,${NbreDoublon}d" $NameFileTerre2 > $tmpFile2`
    
    tester2=`cat $tmpFile2 >> $NewFileTerre`
    echo "Nombre de ligne du nouveau fichier mergé " `cat $NewFileTerre  | wc -l`
    echo ""
    echo "Creation du nouveau fichier pour la terre: DONE"
else
    echo "********************************************"
    echo "ERROR: Revoir orientation des données   "
    echo "********************************************"
    exit
fi
cp $NewFileCote ../
cp $NewFileTerre ../
rm tmp*.txt
echo "==============================================================="
echo "                           END                                 "
echo "==============================================================="
