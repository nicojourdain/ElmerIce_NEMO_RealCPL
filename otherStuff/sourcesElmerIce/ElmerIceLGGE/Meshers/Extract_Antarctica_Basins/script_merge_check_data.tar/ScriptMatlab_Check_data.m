clear all
%Choisir le format du fichier: [.txt] ou [.csv]
plotAll='txt';

if strcmp(plotAll,'csv')
    %Lecture fichier avec les donnees Terre
    %---------------------------------------
    Terre=csvread('./Basin11_Terre.csv');
    
    %Lecture fichier avec les donnees cote
    %--------------------------------------
    Mer=csvread('./Basin11_Mer.csv');
    
    plot(Terre(:,1),Terre(:,2),Mer(:,1),Mer(:,2))
    
elseif strcmp(plotAll,'txt')
    %Lecture fichier avec les donnees Terre
    %---------------------------------------
    load ./MergeCote.txt
    xMer=MergeCote(:,1);
    yMer=MergeCote(:,2);
    
    %Lecture fichier avec les donnees cote
    %--------------------------------------
    load ./MergeTerre.txt
    xTerre=MergeTerre(:,1);
    yTerre=MergeTerre(:,2);
    
    plot(xTerre(:),yTerre(:),xMer(:),yMer(:))
end
